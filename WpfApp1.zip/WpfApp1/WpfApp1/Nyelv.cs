﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public enum Nyelvcsaladok { moduláris, strukturált, funkcionális, objektumorientált };
    public class Nyelv
    {
        string neve;
        bool forditosE;
        int megjelenesEve;
        bool alacsonyszintuE;
        int nepszeruseg2022;  //
        Nyelvcsaladok nyelvcsalad;
        public Nyelv(string neve,
                     bool forditosE,
                     int megjelenesEve,
                     bool alacsonyszintuE,
                     int nepszeruseg2022,
                     Nyelvcsaladok nyelvcsalad)
        {
            this.neve = neve;
            this.forditosE = forditosE;
            this.megjelenesEve = megjelenesEve;
            this.alacsonyszintuE = alacsonyszintuE;
            this.nepszeruseg2022 = nepszeruseg2022;
            this.nyelvcsalad = nyelvcsalad;
        }
        public string Neve { get => neve; }
        public bool ForditosE { get => forditosE; }
        public int MegjelenesEve { get => megjelenesEve; }
        public bool AlacsonyszintuE { get => alacsonyszintuE; }
        public int Nepszeruseg2022 { get => nepszeruseg2022; }
        public Nyelvcsaladok Nyelvcsalad { get => nyelvcsalad; }
        public bool NepszeruE()
        {
            return this.Nepszeruseg2022 < 4;
        }

        static int ForditosEM(bool ford)
        {
            if (ford == true)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        static int AlacsonyszintuEM(bool alacsony)
        {
            if (alacsony == true)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }


        public string Osszefuz()
        {
            return $"{this.Neve}; {ForditosEM(this.ForditosE)}; {this.MegjelenesEve}; {AlacsonyszintuEM(this.AlacsonyszintuE)}; {this.Nepszeruseg2022}; {Nyelvcsalad}";
        }
    }
}
