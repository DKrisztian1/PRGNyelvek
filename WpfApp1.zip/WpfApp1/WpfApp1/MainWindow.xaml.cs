﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();   
        }

        
        private void Rogzit(object sender, RoutedEventArgs e)
        {
            string nev = txtNev.Text;
            int megjelenes = Convert.ToInt32(txtMegjelenes.Text);
            int nepszeruseg = Convert.ToInt32(sliNepszeruseg.Value);
            bool forditosE = false;
            bool magasszintu = false;
            Nyelvcsaladok nyelv = Nyelvcsaladok.moduláris;

            if (rdoMagasSzintu.IsChecked == true)
                magasszintu = true;

            if (rdoFordito.IsChecked == true)
                forditosE = true;

            if (cboNyelvCsalad.SelectedItem.ToString() == "Moduláris")
            {
                nyelv = Nyelvcsaladok.moduláris;
            }

            else if (cboNyelvCsalad.SelectedItem.ToString() == "Strukturális")
            {
                nyelv = Nyelvcsaladok.strukturált;
            }

            else if (cboNyelvCsalad.SelectedItem.ToString() == "Funkcionális")
            {
                nyelv = Nyelvcsaladok.funkcionális;
            }

            else if (cboNyelvCsalad.SelectedItem.ToString() == "Objektumorientált")
            {
                nyelv = Nyelvcsaladok.objektumorientált;
            }


            Nyelv xy = new Nyelv(nev, forditosE, megjelenes, magasszintu, nepszeruseg, nyelv);
            StreamWriter sw = new StreamWriter("nyelvek.txt", append:true);
            sw.WriteLine($"{nev}; {megjelenes}; {forditosE}; {magasszintu}");
            
        }
    }
}
